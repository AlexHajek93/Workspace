
public interface Interface {
	abstract boolean run();
	abstract void fix();
	abstract void eval();
}
