package com.revature.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ers.beans.*;
import ers.dao.ErsDAO;

public class MasterServlet extends HttpServlet{
	
	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ErsDAO dao = new ErsDAO();
		ErsUser info;
		switch(req.getRequestURI()){
		case "/ERS_Web/login.do": 
			if((info = dao.retrieveUser(req.getParameter("user")))!=null){
				if(info.getPassword().equals(req.getParameter("pass")))
					if(info.getRole().getRole()!=2){
						System.out.println("password match");
						req.getSession().setAttribute("userid", info.getId());
						req.getSession().setAttribute("username", info.getFname());
						req.getSession().setAttribute("userRole", info.getRole().getRole());
						resp.sendRedirect("page.jsp");
					}
					else if(info.getRole().getRole()==2){
						System.out.println("password match");
						req.getSession().setAttribute("userid", info.getId());
						req.getSession().setAttribute("username", info.getFname());
						resp.sendRedirect("page.jsp");
					}
				else{
					System.out.println("password failed");
					req.getSession().setAttribute("loginFail", "Login failed, I guess you don't know who you are...");
					resp.sendRedirect("login.jsp");
				}
			}else{
			System.out.println("password failed");
			req.setAttribute("loginFail", "Login failed, I guess you don't know who you are...");
			resp.sendRedirect("login.jsp");
			}
			break;
		case "/ERS_Web/ureg.do": 
			//Needs work
			info = new ErsUser();
			info.setId(1);
			info.setUsername(req.getParameter("user"));
			info.setPassword(req.getParameter("pass"));
			info.setFname(req.getParameter("fname"));
			info.setLname(req.getParameter("lname"));
			info.setEmail(req.getParameter("email"));
			info.setRole(new ErsRole(1,""));
			System.out.println("creating user...");
			System.out.println(info);
			if(dao.createUser(info)){
				req.getSession().setAttribute("userid", info.getId());
				req.getSession().setAttribute("username", info.getFname());
				req.getSession().setAttribute("userRole", info.getRole().getRole());
				resp.sendRedirect("page.jsp");
			}else{
				System.out.println("registration failed");
				req.setAttribute("regFail", "Registration failed, Try again or don't...");
				resp.sendRedirect("ureg.jsp");
			}
			break;
		case "/ERS_Web/mstate1.do": 
			req.getSession().setAttribute("mstate", 1);
			resp.sendRedirect("mstate.jsp"); 
			break;
		case "/ERS_Web/mstate2.do": 
			req.getSession().setAttribute("mstate", 2);
			resp.sendRedirect("mstate.jsp"); 
			break;
		case "/ERS_Web/mstate3.do": 
			req.getSession().setAttribute("mstate", 3);
			resp.sendRedirect("mstate.jsp"); 
			break;
		case "/ERS_Web/mstate4.do": 
			req.getSession().setAttribute("mstate", 4);
			resp.sendRedirect("mstate.jsp"); 
			break;
		case "/ERS_Web/ustate1.do": 
			req.getSession().setAttribute("ustate", 1);
			resp.sendRedirect("ustate.jsp"); 
			break;
		case "/ERS_Web/ustate2.do": 
			req.getSession().setAttribute("ustate", 2);
			resp.sendRedirect("ustate.jsp"); 
			break;
		case "/ERS_Web/nstat.do": 
			if(dao.createStat(new ErsStatus(1,req.getParameter("newstat"))))
				resp.sendRedirect("mpage.jsp"); 
			else
				resp.sendRedirect("mstate.jsp");
			break;
		case "/ERS_Web/ntype.do": 
			if(dao.createType(new ErsType(1,req.getParameter("newtype"))))
				resp.sendRedirect("mpage.jsp"); 
			else
				resp.sendRedirect("mstate.jsp"); 
			break;
		case "/ERS_Web/nrole.do": 
			if(dao.createRole(new ErsRole(1,req.getParameter("newrole"))))
				resp.sendRedirect("mpage.jsp"); 
			else
				resp.sendRedirect("mstate.jsp");
			break;
		case "/ERS_Web/process.do":
			
			resp.sendRedirect("mpage.jsp");
			break;
		case "/ERS_Web/nreim.do": 
			resp.sendRedirect("upage.jsp");
			break;
		case "/ERS_Web/creim.do":
			resp.sendRedirect("upage.jsp");
			break;
		case "/ERS_Web/logout.do":
			req.getSession().invalidate();
			resp.sendRedirect("reimburse.jsp");
			break;
		default: throw new IllegalArgumentException("Invalid URI");
		}
	}
}
