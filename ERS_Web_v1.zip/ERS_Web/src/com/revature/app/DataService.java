package com.revature.app;

import com.revature.beans.HelloBean;

public class DataService {
		public void saveHelloBean(HelloBean model){
			//connect to DB
			//open transaction
			//call dao methods
			//new HelloDao.insert(model);
			//commit/rollback
			//DONE
		}
}
