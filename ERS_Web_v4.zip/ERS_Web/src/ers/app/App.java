package ers.app;

import java.util.List;

import ers.beans.*;

import ers.dao.ErsDAO;

public class App {
//	public static void main(String[] args) {
//		ErsDAO dao = new ErsDAO();
//		dao.createUser(new ErsUser(1,"Secondary","password","Seco","Dary","seco@dary",dao.retrieveRole(2)));
//		List<ErsReimbursement> listReim = dao.getAllReims();
//		for(ErsReimbursement t : listReim) {
//			System.out.println(t);
//		}
//		List<ErsUser> listUser = dao.getAllUsers();
//		for(ErsUser t : listUser) {
//			System.out.println(t);
//		}
//		List<ErsRole> listRole = dao.getAllRoles();
//		for(ErsRole t : listRole) {
//			System.out.println(t);
//		}
//		List<ErsStatus> listStat = dao.getAllStats();
//		for(ErsStatus t : listStat) {
//			System.out.println(t);
//		}
//		List<ErsType> listType = dao.getAllTypes();
//		for(ErsType t : listType) {
//			System.out.println(t);
//		}
//		
//	}
}
