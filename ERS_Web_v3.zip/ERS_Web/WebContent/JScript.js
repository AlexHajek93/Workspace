/**
 * 
 */
$(document).ready(function(){
	$('.reim_table').DataTable();
});